$Id: README.txt,v 1.4 2010/06/03 04:51:43 garrettalbright Exp $

Zenophile
by Garrett Albright
My Drupal user page:
http://drupal.org/user/191212

This module's project page:
http://drupal.org/project/Zenophile

Zenophile allows themers to very easily create Zen subthemes without all the
tedious file copying and find-and-replacing required when creating subthemes by
hand.

Five-second instructions:
Install the module and go to Administration > Site building > Themes. Click the
"Create Zen subtheme" tab.

For more information, check out Zenophile's documentation page here:
http://drupal.org/node/593726

Thanks for trying Zenophile!