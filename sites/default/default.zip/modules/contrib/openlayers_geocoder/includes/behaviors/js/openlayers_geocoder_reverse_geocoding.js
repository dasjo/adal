// $Id: openlayers_geocoder_reverse_geocoding.js,v 1.1.2.2 2010/04/26 08:58:48 antoniodemarco Exp $

/**
 * @file Openlayers Geocoder reverse geocoding behavior 
 */


