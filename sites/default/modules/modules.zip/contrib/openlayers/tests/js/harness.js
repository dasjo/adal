// $Id: harness.js,v 1.1.2.1 2010/02/08 23:20:57 tmcw Exp $
Drupal = {};
Drupal.openlayers = {};
Drupal.settings = {};
Drupal.behaviors = {};
