<?php
// $Id: openlayers-views-map.tpl.php,v 1.1.2.4 2010/07/02 14:52:02 tmcw Exp $

/**
 * @file
 * Template file for map
 */
?>
<?php if (!empty($rows)): ?>
  <div class='openlayers-views-map'><?php print $rows ?></div>
<?php endif; ?>
