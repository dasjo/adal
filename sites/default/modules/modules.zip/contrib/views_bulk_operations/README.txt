Please refer to the module page at http://drupal.org/project/views_bulk_operations for quick start instructions.
