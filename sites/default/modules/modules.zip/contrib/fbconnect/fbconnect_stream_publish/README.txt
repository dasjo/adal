/* $Id */

This module allows to publish nodes to user's facebook wall.
To enable it go to admin/content/node-type/<type> and check Facebook Stream Publish section 