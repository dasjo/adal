/* $Id: README.txt,v 1.1.2.1 2010/08/30 13:52:26 vectoroc Exp $ */

If you want to use fbconnect with fb_social module just enable fbconnect_fb_social