<!-- adal menu -->
<div class="adal_menu">
	<a href="<?php print base_path() ?>" class="logo"><span class="text">Auslandsdienst Alumni Club</span></a>

	<ul class="icons">
		<li><a href="<?php print base_path() ?>info" rel="lightframe[a|width:980px;height:500px][]" class="info icon"><span>Info</span></a></li>
		<li><a href="<?php print base_path() ?>news" rel="lightframe[b|width:980px;height:500px][]" class="news icon"><span>News</span></a></li>
		<li><a href="<?php print base_path() ?>magazine" rel="lightframe[c|width:980px;height:500px][]" class="magazine icon"><span>Magazine</span></a></li>
		<li><a href="<?php print base_path() ?>contact" rel="lightframe[d|width:980px;height:500px][]" class="contact icon"><span>Contact</span></a></li>
		<li><a href="http://www.facebook.com/group.php?gid=8197067511" class="facebook icon"><span>Facebook</span></a></li>
	</ul>
</div>
